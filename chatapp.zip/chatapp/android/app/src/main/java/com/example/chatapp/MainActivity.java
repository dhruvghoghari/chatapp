package com.example.chatapp;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
