class Constants
{
  static String baseUrl = "https://api.viosa.in/user/auth/";
  static String fcm_token = '';
  static bool isLoggedIn = false;
  static String userType = '';
  static String appVersion = '';



}